
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

app.post('/save-chat', async (req, res) => {
  const { user_id, role, message } = req.body;
  const { data, error } = await supabase.from('chat_history').insert([{ user_id, role, message }]);
  if (error) return res.status(500).json({ error });
  res.json({ success: true, data });
});

app.listen(4000, () => console.log('EduWorld Cloud API running on port 4000'));
