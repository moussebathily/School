
import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, Text, ScrollView } from 'react-native';
import * as Speech from 'expo-speech';
import Voice from '@react-native-voice/voice';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ChatIA() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    loadHistory();
    Voice.onSpeechResults = (result) => {
      const text = result.value[0];
      setInput(text);
    };
  }, []);

  async function loadHistory() {
    const saved = await AsyncStorage.getItem('chatHistory');
    if (saved) setMessages(JSON.parse(saved));
  }

  async function saveHistory(newMessages) {
    await AsyncStorage.setItem('chatHistory', JSON.stringify(newMessages));
  }

  async function sendQuestion() {
    const newMessages = [...messages, { role: 'user', text: input }];
    setMessages(newMessages);
    setInput('');
    saveHistory(newMessages);

    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer sk-votre_cle_api`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'Tu es un assistant éducatif' },
          ...newMessages.map(m => ({ role: m.role, content: m.text }))
        ]
      })
    });
    const data = await res.json();
    const answer = data.choices[0].message.content;
    const updatedMessages = [...newMessages, { role: 'assistant', text: answer }];
    setMessages(updatedMessages);
    Speech.speak(answer);
    saveHistory(updatedMessages);

    await fetch('http://localhost:4000/save-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: 'U123', role: 'assistant', message: answer })
    });
  }

  function startListening() {
    Voice.start('fr-FR');
  }

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <ScrollView style={{ flex: 1 }}>
        {messages.map((m, i) => (
          <Text key={i} style={{ color: m.role === 'user' ? 'blue' : 'green' }}>{m.role}: {m.text}</Text>
        ))}
      </ScrollView>
      <TextInput value={input} onChangeText={setInput} placeholder="Parle ou écris ici" style={{ borderWidth: 1, marginBottom: 10 }} />
      <Button title="Envoyer" onPress={sendQuestion} />
      <Button title="🎤 Parler" onPress={startListening} />
    </View>
  );
}
