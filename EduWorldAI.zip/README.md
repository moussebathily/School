# EduWorld AI

Application éducative React Native avec intégration IA GPT-4o et Supabase.

## Installation

1. Cloner le projet
2. Installer les dépendances : `npm install` ou `yarn install`
3. Configurer Supabase dans `/config/supabase.js`
4. Lancer l'application : `npm start` ou `expo start`

## Fonctionnalités

- Authentification avec Supabase
- Micro-apprentissage multilingue
- Intégration GPT-4o pour assistance éducative