import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import VideoPlayer from '../components/VideoPlayer';

export default function LectureScreen() {
  const videoSource = { uri: 'https://www.w3schools.com/html/mov_bbb.mp4' };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Module Lecture - Exemple vidéo éducative</Text>
      <VideoPlayer source={videoSource} />
      <Button title="Écouter Audio Exemple" onPress={() => alert('Fonction TTS à implémenter')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 20, marginBottom: 15, fontWeight: 'bold' },
});