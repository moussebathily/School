import React, { useState } from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet } from 'react-native';
import { askEduAI } from '../../ai/gpt-helper';

export default function ChatIAScreen() {
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleAsk() {
    setLoading(true);
    const res = await askEduAI(question, 'fr');
    setResponse(res);
    setLoading(false);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Chat éducatif IA</Text>
      <TextInput
        style={styles.input}
        placeholder="Pose ta question..."
        value={question}
        onChangeText={setQuestion}
        editable={!loading}
      />
      <Button title={loading ? 'Patiente...' : 'Poser la question'} onPress={handleAsk} disabled={loading || !question} />
      <ScrollView style={styles.responseContainer}>
        <Text>{response}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, marginBottom: 10, fontWeight: 'bold', textAlign: 'center' },
  input: {
    height: 40,
    borderColor: '#666',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  responseContainer: {
    marginTop: 10,
  },
});