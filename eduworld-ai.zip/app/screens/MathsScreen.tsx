import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function MathsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Module Mathématiques - Exemple de quiz simple</Text>
      <Text>1 + 1 = ?</Text>
      {/* TODO: ajouter quiz interactif */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 20, marginBottom: 15, fontWeight: 'bold' },
});