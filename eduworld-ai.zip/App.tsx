import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './app/screens/HomeScreen';

import LectureScreen from './app/screens/LectureScreen';
import MathsScreen from './app/screens/MathsScreen';
import ChatIAScreen from './app/screens/ChatIAScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'EduWorld AI' }} />
        <Stack.Screen name="Lecture" component={LectureScreen} options={{ title: 'Lecture' }} />
        <Stack.Screen name="Maths" component={MathsScreen} options={{ title: 'Mathématiques' }} />
        <Stack.Screen name="ChatIA" component={ChatIAScreen} options={{ title: 'Chat IA' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}