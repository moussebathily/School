import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function askEduAI(question, language = 'fr') {
  const prompt = `
  Tu es un professeur patient et pédagogue, parlant ${language}.
  Explique clairement la réponse et corrige les erreurs si l'utilisateur en fait.
  Réponds avec des exemples simples adaptés à un enfant.
  Question: ${question}
  `;

  const completion = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: prompt }],
  });

  return completion.choices[0].message.content;
}